package com.mindtree.service;

import java.util.List;

import com.mindtree.entity.Employees;
import com.mindtree.entity.Events;
import com.mindtree.exception.ServiceException;

public interface EventRegistrationService {
	
	public String registerEmployee(Employees employee);
	public List<Employees> allEmployees() throws ServiceException;
	public Events findEvents(int ids) throws ServiceException;

}
