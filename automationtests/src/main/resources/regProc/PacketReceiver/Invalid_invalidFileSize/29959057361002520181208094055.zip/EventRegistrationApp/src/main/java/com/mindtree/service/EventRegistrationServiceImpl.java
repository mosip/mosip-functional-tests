package com.mindtree.service;

import java.util.ArrayList;
import java.util.List;

import com.mindtree.dao.EventRegistrationDao;
import com.mindtree.dao.EventRegistrationDaoImpl;
import com.mindtree.entity.Employees;
import com.mindtree.entity.Events;
import com.mindtree.exception.DataAccessException;
import com.mindtree.exception.ServiceException;

public class EventRegistrationServiceImpl implements EventRegistrationService{

	public String registerEmployee(Employees employee) {
		EventRegistrationDao eventRegistrationDao = new EventRegistrationDaoImpl();
		String result = eventRegistrationDao.registerEmployee(employee);
		return result;
	}

	public List<Employees> allEmployees() throws ServiceException {
		EventRegistrationDao eventRegistrationDao = new EventRegistrationDaoImpl();
		List<Employees> employees = new ArrayList<Employees>();
		try {
			employees = eventRegistrationDao.allEmployees();
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new ServiceException();
		}
		return employees;
	}

	public Events findEvents(int ids) throws ServiceException {
		EventRegistrationDao eventRegistrationDao = new EventRegistrationDaoImpl();
		Events event = new Events();
		try {
			event = eventRegistrationDao.findEvents(ids);
		} catch (DataAccessException e) {
			e.printStackTrace();
			throw new ServiceException();
		}
		return event;
	}

}
