package com.mindtree.dao;

import java.util.List;

import com.mindtree.entity.Employees;
import com.mindtree.entity.Events;
import com.mindtree.exception.DataAccessException;

public interface EventRegistrationDao {
	
	public String registerEmployee(Employees employee);
	public List<Employees> allEmployees() throws DataAccessException;
	public Events findEvents(int id) throws DataAccessException;

}
