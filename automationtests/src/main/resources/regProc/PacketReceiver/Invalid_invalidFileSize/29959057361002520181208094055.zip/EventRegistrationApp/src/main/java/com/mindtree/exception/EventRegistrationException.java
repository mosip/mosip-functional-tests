package com.mindtree.exception;

public class EventRegistrationException extends Exception{

	public EventRegistrationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EventRegistrationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public EventRegistrationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public EventRegistrationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public EventRegistrationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
