package com.demo.ceph_fs_check;

import java.io.FileNotFoundException;
import java.util.List;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.Bucket;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.util.StringUtils;

public class S3Ceph {

	private static final String ACCESS_KEY = "P9OJLQY2WS4GZLOEF8LH";
	private static final String SECRET_KEY = "jAx8v9XejubN42Twe0ooBakXd1ihM2BvTiOMiC2M";

	public static void main(String[] args) throws AmazonServiceException, SdkClientException, FileNotFoundException {
		AWSCredentials credentials = new BasicAWSCredentials(ACCESS_KEY, SECRET_KEY);
		ClientConfiguration clientConfig = new ClientConfiguration();
		clientConfig.setProtocol(Protocol.HTTP);
		@SuppressWarnings("deprecation")
		AmazonS3 conn = new AmazonS3Client(credentials, clientConfig);
		conn.setEndpoint("http://104.211.219.29:7480");
		List<Bucket> buckets = conn.listBuckets();
		//for (Bucket bucket : buckets) {
			ObjectListing objects = conn.listObjects("20916100110014920190218154630");	
			/*do {*/
				for (S3ObjectSummary objectSummary : objects.getObjectSummaries()) {
					System.out.println(objectSummary.getKey() /*+ "\t" + objectSummary.getSize() + "\t"
							+ StringUtils.fromDate(objectSummary.getLastModified())*/);
					//String key = objectSummary.getKey();
					//conn.deleteObject(bucket.getName(), key);
				}
				//System.out.println(objects.getObjectSummaries().get(0));
				
				//objects = conn.listNextBatchOfObjects(objects);
			/*} while (objects.isTruncated());
		//	System.out.println(bucket.getName() + "\t" + StringUtils.fromDate(bucket.getCreationDate()));
			//conn.deleteBucket(bucket.getName());*/
//		}

	}

}
