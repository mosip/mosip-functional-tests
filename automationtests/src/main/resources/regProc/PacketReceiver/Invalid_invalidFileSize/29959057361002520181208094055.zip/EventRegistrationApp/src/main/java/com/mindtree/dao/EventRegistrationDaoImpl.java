package com.mindtree.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.mindtree.entity.Employees;
import com.mindtree.entity.Events;
import com.mindtree.exception.DataAccessException;

public class EventRegistrationDaoImpl implements EventRegistrationDao{

	public String registerEmployee(Employees employee) {
		SessionFactory factory  = new Configuration().configure().buildSessionFactory();
		Session session = factory.getSessionFactory().openSession();
		session.getTransaction().begin();
		session.save(employee);
		session.getTransaction().commit();
		return "saved";

	}

	@SuppressWarnings("unchecked")
	public List<Employees> allEmployees() throws DataAccessException{
		SessionFactory factory  = new Configuration().configure().buildSessionFactory();
		Session session = factory.getSessionFactory().openSession();
		session.getTransaction().begin();
		List<Employees> employees = (List<Employees>) session.createQuery("from Employees").list();
		
		if(employees== null || employees.isEmpty())
			throw new DataAccessException("List is empty....");
		return employees;

	}

	public Events findEvents(int id) throws DataAccessException {
		SessionFactory factory  = new Configuration().configure().buildSessionFactory();
		Session session = factory.getSessionFactory().openSession();
		session.getTransaction().begin();
		Events event = (Events) session.get(Events.class,id);

		if(event==null)
			throw new DataAccessException();
		return event;
	}

}
