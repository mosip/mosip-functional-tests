package com.demo.ceph_fs_check;

import java.util.Collection;

import org.javaswift.joss.client.factory.AccountConfig;
import org.javaswift.joss.client.factory.AccountFactory;
import org.javaswift.joss.client.factory.AuthenticationMethod;
import org.javaswift.joss.model.Account;
import org.javaswift.joss.model.Container;

public class SwiftCeph {

	public static void main(String[] args) {

		String username = "testuser";
		String password = "XCA7L3b4Fq3CDLk7lAvHZNMy8GoJrkx7BZ5DNd7G";
		String authUrl = "http://35.231.24.138:7480/auth";

		AccountConfig config = new AccountConfig();
		config.setUsername(username);
		config.setPassword(password);
		config.setAuthUrl(authUrl);
		config.setAuthenticationMethod(AuthenticationMethod.BASIC);
		Account account = new AccountFactory(config).createAccount();
		Collection<Container> containers = account.list();
		for (Container currentContainer : containers) {
		    System.out.println(currentContainer.getName());
		}

	}

}
