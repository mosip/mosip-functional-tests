package com.mindtree.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.mindtree.entity.Employees;
import com.mindtree.entity.Events;
import com.mindtree.exception.ServiceException;
import com.mindtree.service.EventRegistrationService;
import com.mindtree.service.EventRegistrationServiceImpl;

public class EventRegistration {
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		EventRegistrationService eventRegistrationService = new EventRegistrationServiceImpl();
		List<Employees> employees = null; 
		int choice = 0;
		System.out.print("Mindtree Event Registration Application" + "\n" + "----------------" + "\n" + "1.Register for events" + "\n"
				+ "2.View all employees" + "\n" + "3.Exit" + "\n" + "Enter the choice:");
		choice = sc.nextInt();
		switch (choice) {
		case 1:
			Scanner sc1 = new Scanner(System.in);
			Employees employee = new Employees();
			
			System.out.println("Enter Employee ID : ");
			int employeeId  = sc1.nextInt();
			
			System.out.println("Enter Employee Name : ");
			String employeeName  = sc1.next();
			
			System.out.println("Enter Join Date in yyyy/MM/dd : ");
			String joindate  = sc1.next();
			  Date join_date = null;
			try {
				join_date = new SimpleDateFormat("yyyy/MM/dd").parse(joindate);
			} catch (ParseException e) {
				e.printStackTrace();
				System.out.println("Format is not proper....");
				System.exit(0);
			}  
			
			System.out.println("Enter Email ID : ");
			String emailId  = sc1.next();
			
			System.out.println("Enter number of events :");
			int eventNum = sc1.nextInt();
			ArrayList<Events> eventList = new ArrayList<Events>();
			if(eventNum> 0){
				
				System.out.println("Enter event ids: ");
				for(int i = 0; i<eventNum; i++){
					int ids = sc1.nextInt();
					Events event =  new Events();
					try {
						event = eventRegistrationService.findEvents(ids);
					} catch (ServiceException e) {
						e.printStackTrace();
					}
					eventList.add(event);
				}
			}
						
			employee.setMid(employeeId);
			employee.setName(employeeName);
			employee.setJoinDate(join_date);
			employee.setEmailId(emailId);
			employee.setEvents(eventList);
			
			String result = eventRegistrationService.registerEmployee(employee);
			System.out.println(result);
			break;
			
			case 2:
			try {
				employees = eventRegistrationService.allEmployees();
			} catch (ServiceException e) {
				e.printStackTrace();
			}
				for(Employees emp:employees){
					System.out.println("Employee MID : "+emp.getMid());
					System.out.println("Employee Name : "+emp.getName());
					System.out.println("Employee JOIN DATE : "+emp.getJoinDate());
					System.out.println("Employee Email Id : "+emp.getEmailId());
				}
				
				break;
		
			case 3:
				System.exit(0);
				break;
		}
	}
	}

